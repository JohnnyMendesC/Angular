export interface Pensamento {
  id?: number
  conteudo: string
  autoria: string
  modelo: string
  favorito: boolean
}


